# Automatic-Video-Summarization
Automatically summarize video by just giving youtube link as input

Done using NLP, LSA Algorithm

Run display.py and open the local host website
